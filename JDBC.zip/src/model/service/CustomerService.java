package model.service;

import exception.ExceptionHandling;
import model.entity.Customer;

import java.util.List;

public interface CustomerService {
    int addCustomer(Customer customer) throws ExceptionHandling;
    int updateCustomer(Customer customer) throws ExceptionHandling;
    int deleteCustomer(Customer customer) throws ExceptionHandling;
    List<Customer> queryAllCustomers() throws ExceptionHandling;
}
