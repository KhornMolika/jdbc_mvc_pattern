package model.service;

import exception.ExceptionHandling;
import model.dao.CustomerDao;
import model.dao.CustomerDaoImpl;
import model.entity.Customer;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

public class CustomerServiceImpl implements CustomerService {
    private final CustomerDao customerDao= new CustomerDaoImpl();

    @Override
    public int addCustomer(Customer customer) throws ExceptionHandling {
        if(customerDao.addCustomer(customer)>0){
            System.out.println("Successfully added customer");
        }else {
            throw new ExceptionHandling("Customer not added");
        }
        return 0;
    }

    @Override
    public int updateCustomer(Customer customer) throws ExceptionHandling {
        return 0;
    }

    @Override
    public int deleteCustomer(Customer customer) throws ExceptionHandling {
        return 0;
    }

    @Override
    public List<Customer> queryAllCustomers() throws ExceptionHandling {
        return List.of();
    }
}
