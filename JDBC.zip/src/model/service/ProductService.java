package model.service;

public interface ProductService {

}
