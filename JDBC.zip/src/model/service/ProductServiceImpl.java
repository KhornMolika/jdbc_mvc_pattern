package model.service;

public class ProductServiceImpl {
}
