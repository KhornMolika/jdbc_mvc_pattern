package model.service;

public class OrderServiceImpl {
}
