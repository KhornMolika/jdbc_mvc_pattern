package model.service;

public interface OrderService {
}
