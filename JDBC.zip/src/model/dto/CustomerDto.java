package model.dto;

import java.sql.Date;

public record CustomerDto(
        Integer id,
        String name,
        String email
) {}
