package mapper;

import model.dto.CreateCustomerDto;
import model.entity.Customer;

import java.sql.Date;
import java.time.LocalDate;
import java.util.Random;

public class Mapper {
    public static Customer fromCreateCustomerDtoToCustomer(CreateCustomerDto createCustomerDto) {
        if(createCustomerDto == null) {
            return null;
        }
        return Customer.builder()
                .id(new Random().nextInt(10000))
                .name(createCustomerDto.name())
                .email(createCustomerDto.email())
                .password(createCustomerDto.password())
                .isDeleted(false)
                .createdDate(Date.valueOf(LocalDate.now()))
                .build();
    }
}
