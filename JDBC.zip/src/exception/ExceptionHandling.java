package exception;

public class ExceptionHandling extends Exception {
    public ExceptionHandling() {super();}
    public ExceptionHandling(String message) {
        super(message);
    }
}
